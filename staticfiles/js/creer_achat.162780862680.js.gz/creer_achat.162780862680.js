document.addEventListener('DOMContentLoaded', function () {
    console.log('Page de création d\'achat chargée.');
    // Ajouter d'autres interactions JavaScript si nécessaire
});